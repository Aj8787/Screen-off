# Screen Off Timer

Native Android app built with **Kotlin + Jetpack Compose + Material 3 + Jetpack Glance**.

- No backend; all data is stored locally on-device.
- Material You, pure Dark and pure Light appearance modes are shared by the app, time picker and home-screen widget.
- Material You uses Android 12+ dynamic system colors, which are derived from the user's wallpaper/theme.
- Glance widget supports horizontal/vertical resizing and compact layouts.
- Widget transparency is adjustable from the app.
- Screen-off sessions are captured through screen state broadcasts and persisted locally.
- Sleep exclusion supports overnight schedules such as 23:00 → 01:00 or 23:00 → 07:00.
- Usage Access is declared for future/compatible usage-based verification, while screen state events remain the primary timer signal.

## Build

GitHub Actions workflow: `.github/workflows/build.yml`.
Run **Actions → Build APK → Run workflow**. The debug APK is uploaded as an artifact.
