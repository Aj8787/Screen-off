package com.example.screenofftimer

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ScreenOffTimerApp() }
    }
}

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val mode = Store.theme(context)
    val dark = when (mode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val scheme = when (mode) {
        1 -> darkColorScheme(background = androidx.compose.ui.graphics.Color.Black, surface = androidx.compose.ui.graphics.Color.Black, onBackground = androidx.compose.ui.graphics.Color.White, onSurface = androidx.compose.ui.graphics.Color.White)
        2 -> lightColorScheme(background = androidx.compose.ui.graphics.Color.White, surface = androidx.compose.ui.graphics.Color.White, onBackground = androidx.compose.ui.graphics.Color.Black, onSurface = androidx.compose.ui.graphics.Color.Black)
        else -> if (android.os.Build.VERSION.SDK_INT >= 31) {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else if (dark) darkColorScheme() else lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScreenOffTimerApp() {
    AppTheme {
        val context = LocalContext.current
        var theme by remember { mutableIntStateOf(Store.theme(context)) }
        var sleepEnabled by remember { mutableStateOf(Store.isSleepScheduleEnabled(context)) }
        var start by remember { mutableIntStateOf(Store.sleepStart(context)) }
        var end by remember { mutableIntStateOf(Store.sleepEnd(context)) }
        var transparency by remember { mutableFloatStateOf(Store.widgetTransparency(context).toFloat()) }
        var pickerStart by remember { mutableStateOf(false) }
        var pickerEnd by remember { mutableStateOf(false) }
        var usageGranted by remember { mutableStateOf(UsageAccess.isGranted(context)) }
        var tick by remember { mutableLongStateOf(0L) }

        LaunchedEffect(Unit) {
            while (true) { tick = System.currentTimeMillis(); delay(1000) }
        }

        val total = TimeCalc.format(TimeCalc.adjustedToday(context, tick))
        val longest = TimeCalc.format(TimeCalc.longestToday(context, tick))

        Scaffold { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(6.dp))
                Text("Screen Off Timer", style = MaterialTheme.typography.headlineLarge)
                Text(total, style = MaterialTheme.typography.displaySmall)
                Text("Longest session  •  $longest", style = MaterialTheme.typography.titleMedium)

                ElevatedButton(onClick = { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (usageGranted) "Usage Access granted" else "Grant Usage Access")
                }

                Card(shape = MaterialTheme.shapes.extraLarge) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sleep exclusion", style = MaterialTheme.typography.titleLarge)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text("Exclude sleep time", modifier = Modifier.weight(1f))
                            Switch(checked = sleepEnabled, onCheckedChange = { sleepEnabled = it; Store.setSleepScheduleEnabled(context, it); ScreenOffWidget().updateAll(context) })
                        }
                        FilledTonalButton(onClick = { pickerStart = true }, modifier = Modifier.fillMaxWidth()) { Text("Sleep starts  •  ${formatClock(start, context)}") }
                        FilledTonalButton(onClick = { pickerEnd = true }, modifier = Modifier.fillMaxWidth()) { Text("Sleep ends  •  ${formatClock(end, context)}") }
                    }
                }

                Card(shape = MaterialTheme.shapes.extraLarge) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Appearance", style = MaterialTheme.typography.titleLarge)
                        Text("Same theme is used in the app, clock picker and widget.", style = MaterialTheme.typography.bodyMedium)
                        ThemeOption("Material You", Icons.Rounded.Palette, theme == 0) { theme = 0; Store.setTheme(context, 0); ScreenOffWidget().updateAll(context) }
                        ThemeOption("Dark", Icons.Rounded.DarkMode, theme == 1) { theme = 1; Store.setTheme(context, 1); ScreenOffWidget().updateAll(context) }
                        ThemeOption("Light", Icons.Rounded.LightMode, theme == 2) { theme = 2; Store.setTheme(context, 2); ScreenOffWidget().updateAll(context) }
                    }
                }

                Card(shape = MaterialTheme.shapes.extraLarge) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Widget transparency", style = MaterialTheme.typography.titleLarge)
                        Text("${transparency.toInt()}%", style = MaterialTheme.typography.labelLarge)
                        Slider(value = transparency, onValueChange = { transparency = it; Store.setWidgetTransparency(context, it.toInt()); ScreenOffWidget().updateAll(context) }, valueRange = 0f..95f)
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
        }

        if (pickerStart) {
            TimePickerDialog(start, context, onDismiss = { pickerStart = false }) { value -> start = value; Store.setSleep(context, start, end); ScreenOffWidget().updateAll(context); pickerStart = false }
        }
        if (pickerEnd) {
            TimePickerDialog(end, context, onDismiss = { pickerEnd = false }) { value -> end = value; Store.setSleep(context, start, end); ScreenOffWidget().updateAll(context); pickerEnd = false }
        }
        LaunchedEffect(Unit) { usageGranted = UsageAccess.isGranted(context) }
    }
}

@Composable
private fun ThemeOption(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = MaterialTheme.shapes.extraLarge, tonalElevation = if (selected) 2.dp else 0.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null)
            Spacer(Modifier.width(14.dp)); Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialog(value: Int, context: android.content.Context, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    val state = rememberTimePickerState(initialHour = value / 60, initialMinute = value % 60, is24Hour = android.text.format.DateFormat.is24HourFormat(context))
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = { onConfirm(state.hour * 60 + state.minute) }) { Text("Done") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }, text = { TimePicker(state) })
}

private fun formatClock(minutes: Int, context: android.content.Context): String {
    val h = minutes / 60; val m = minutes % 60
    return if (android.text.format.DateFormat.is24HourFormat(context)) "%02d:%02d".format(Locale.US, h, m) else {
        val h12 = if (h % 12 == 0) 12 else h % 12
        "%d:%02d %s".format(Locale.US, h12, m, if (h >= 12) "PM" else "AM")
    }
}

object UsageAccess {
    fun isGranted(context: android.content.Context): Boolean = try {
        val us = context.getSystemService(android.app.usage.UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        us.queryUsageStats(android.app.usage.UsageStatsManager.INTERVAL_DAILY, now - 60_000, now).isNotEmpty()
    } catch (_: Exception) { false }
}
