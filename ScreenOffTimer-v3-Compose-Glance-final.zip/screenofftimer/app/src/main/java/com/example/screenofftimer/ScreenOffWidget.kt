package com.example.screenofftimer

import android.content.Context
import android.content.Intent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.glance.*
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.unit.ColorProvider
import androidx.glance.layout.*
import androidx.glance.text.*

class ScreenOffWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ScreenOffWidget()
}

class ScreenOffWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { WidgetContent(context) }
    }

    @Composable
    private fun WidgetContent(context: Context) {
        val total = TimeCalc.format(TimeCalc.adjustedToday(context))
        val longest = TimeCalc.format(TimeCalc.longestToday(context))
        val mode = Store.theme(context)
        val night = androidx.compose.foundation.isSystemInDarkTheme()

        val (bgColor, fgColor, secondaryColor) = when (mode) {
            1 -> Triple(android.graphics.Color.BLACK, android.graphics.Color.WHITE, 0xFFD6D6D6.toInt())
            2 -> Triple(android.graphics.Color.WHITE, android.graphics.Color.BLACK, 0xFF555555.toInt())
            else -> {
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    val bg = context.getColor(if (night) android.R.color.system_neutral1_800 else android.R.color.system_accent1_100)
                    val fg = context.getColor(if (night) android.R.color.system_neutral1_100 else android.R.color.system_neutral1_900)
                    val sub = context.getColor(if (night) android.R.color.system_neutral2_200 else android.R.color.system_neutral2_700)
                    Triple(bg, fg, sub)
                } else Triple(0xFFE9E3FF.toInt(), 0xFF211F26.toInt(), 0xFF625B71.toInt())
            }
        }

        val alpha = (100 - Store.widgetTransparency(context)).coerceIn(5, 100) / 100f
        val bg = android.graphics.Color.argb((alpha * 255).toInt(), android.graphics.Color.red(bgColor), android.graphics.Color.green(bgColor), android.graphics.Color.blue(bgColor))
        val background = ColorProvider(androidx.compose.ui.graphics.Color(bg), androidx.compose.ui.graphics.Color(bg))
        val foreground = ColorProvider(androidx.compose.ui.graphics.Color(fgColor), androidx.compose.ui.graphics.Color(fgColor))
        val secondary = ColorProvider(androidx.compose.ui.graphics.Color(secondaryColor), androidx.compose.ui.graphics.Color(secondaryColor))
        val size = LocalSize.current
        val compact = size.width < 145.dp || size.height < 75.dp

        Box(
            modifier = GlanceModifier.fillMaxSize().background(background).cornerRadius(28.dp).padding(if (compact) 10.dp else 16.dp)
                .clickable(actionStartActivity(Intent(context, MainActivity::class.java)))
        ) {
            Column(modifier = GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Text("SCREEN OFF TIME", style = TextStyle(color = foreground, fontSize = if (compact) 9.sp else 10.sp, fontWeight = FontWeight.Bold))
                Text(total, style = TextStyle(color = foreground, fontSize = if (compact) 24.sp else 30.sp, fontWeight = FontWeight.Bold))
                if (!compact) {
                    Spacer(GlanceModifier.height(3.dp))
                    Text("LONGEST SESSION", style = TextStyle(color = secondary, fontSize = 9.sp, fontWeight = FontWeight.Bold))
                    Text(longest, style = TextStyle(color = foreground, fontSize = 19.sp, fontWeight = FontWeight.Bold))
                }
            }
        }
    }

    companion object {
        fun updateAll(context: Context) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Default).launch {
                ScreenOffWidget().updateAll(context)
            }
        }
    }
}
