package com.example.screenofftimer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScreenStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val c = context.applicationContext
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> {
                // Do not overwrite an existing start if Android sends a duplicate broadcast.
                if (Store.offStart(c) <= 0L) {
                    Store.setOffStart(c, System.currentTimeMillis())
                }
                ScreenOffWidget.updateAll(c)
            }

            Intent.ACTION_SCREEN_ON -> {
                val start = Store.offStart(c)
                if (start > 0L) {
                    val now = System.currentTimeMillis()
                    TimeCalc.recordSession(c, start, now)
                    TimeCalc.splitAndAddSegment(c, start, now)
                    Store.clearOffStart(c)
                }
                ScreenOffWidget.updateAll(c)
            }

            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                ScreenOffWidget.updateAll(c)
            }
        }
    }
}
