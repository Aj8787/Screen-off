package com.example.screenofftimer

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

object Store {
    private const val PREF = "state"
    private const val KEY_OFF_START = "off_start"
    private const val KEY_SCHEDULE_ENABLED = "schedule_enabled"
    private const val KEY_SLEEP_START = "sleep_start"
    private const val KEY_SLEEP_END = "sleep_end"
    private const val KEY_DAILY = "daily_totals"
    private const val KEY_LONGEST = "longest_sessions"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_TRANSPARENCY = "widget_transparency"

    private const val DEFAULT_START = 23 * 60
    private const val DEFAULT_END = 7 * 60

    fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun isSleepScheduleEnabled(c: Context) = prefs(c).getBoolean(KEY_SCHEDULE_ENABLED, false)
    fun setSleepScheduleEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_SCHEDULE_ENABLED, v).apply()
    fun sleepStart(c: Context) = prefs(c).getInt(KEY_SLEEP_START, DEFAULT_START)
    fun sleepEnd(c: Context) = prefs(c).getInt(KEY_SLEEP_END, DEFAULT_END)
    fun setSleep(c: Context, start: Int, end: Int) = prefs(c).edit().putInt(KEY_SLEEP_START, start).putInt(KEY_SLEEP_END, end).apply()

    fun offStart(c: Context) = prefs(c).getLong(KEY_OFF_START, 0L)
    fun setOffStart(c: Context, t: Long) = prefs(c).edit().putLong(KEY_OFF_START, t).apply()
    fun clearOffStart(c: Context) = prefs(c).edit().remove(KEY_OFF_START).apply()

    // 0 = Material You, 1 = Dark, 2 = Light
    fun theme(c: Context) = prefs(c).getInt(KEY_THEME, 0)
    fun setTheme(c: Context, v: Int) = prefs(c).edit().putInt(KEY_THEME, v).apply()

    // 0..100, higher means more transparent.
    fun widgetTransparency(c: Context) = prefs(c).getInt(KEY_TRANSPARENCY, 18)
    fun setWidgetTransparency(c: Context, v: Int) =
        prefs(c).edit().putInt(KEY_TRANSPARENCY, v.coerceIn(0, 95)).apply()

    fun addDaily(c: Context, date: LocalDate, amount: Long) {
        if (amount <= 0L) return
        val p = prefs(c)
        val obj = try { JSONObject(p.getString(KEY_DAILY, "{}")) } catch (_: Exception) { JSONObject() }
        val key = date.toString()
        obj.put(key, obj.optLong(key, 0L) + amount)
        p.edit().putString(KEY_DAILY, obj.toString()).apply()
    }

    fun setLongest(c: Context, date: LocalDate, amount: Long) {
        if (amount <= 0L) return
        val p = prefs(c)
        val obj = try { JSONObject(p.getString(KEY_LONGEST, "{}")) } catch (_: Exception) { JSONObject() }
        val key = date.toString()
        if (amount > obj.optLong(key, 0L)) p.edit().putString(KEY_LONGEST, obj.put(key, amount).toString()).apply()
    }

    fun longest(c: Context, date: LocalDate): Long {
        val obj = try { JSONObject(prefs(c).getString(KEY_LONGEST, "{}")) } catch (_: Exception) { JSONObject() }
        return obj.optLong(date.toString(), 0L)
    }

    fun daily(c: Context, date: LocalDate): Long {
        val obj = try { JSONObject(prefs(c).getString(KEY_DAILY, "{}")) } catch (_: Exception) { JSONObject() }
        return obj.optLong(date.toString(), 0L)
    }
}

object TimeCalc {
    private const val MINUTE = 60_000L

    fun sleepIntersection(start: Long, end: Long, sleepStartMin: Int, sleepEndMin: Int): Long {
        if (end <= start) return 0L
        val zone = java.time.ZoneId.systemDefault()
        var total = 0L
        var date = java.time.Instant.ofEpochMilli(start).atZone(zone).toLocalDate().minusDays(1)
        val last = java.time.Instant.ofEpochMilli(end - 1).atZone(zone).toLocalDate().plusDays(1)
        while (!date.isAfter(last)) {
            val base = date.atStartOfDay(zone)
            val sleepStart = base.plusMinutes(sleepStartMin.toLong()).toInstant().toEpochMilli()
            val sleepEnd = if (sleepEndMin > sleepStartMin)
                base.plusMinutes(sleepEndMin.toLong()).toInstant().toEpochMilli()
            else
                base.plusDays(1).plusMinutes(sleepEndMin.toLong()).toInstant().toEpochMilli()
            total += maxOf(0L, minOf(end, sleepEnd) - maxOf(start, sleepStart))
            date = date.plusDays(1)
        }
        return total
    }

    fun adjustedSegment(start: Long, end: Long, enabled: Boolean, sleepStart: Int, sleepEnd: Int): Long {
        val raw = maxOf(0L, end - start)
        return if (enabled) maxOf(0L, raw - sleepIntersection(start, end, sleepStart, sleepEnd)) else raw
    }

    fun recordSession(c: Context, start: Long, end: Long) {
        if (end <= start) return
        val zone = java.time.ZoneId.systemDefault()
        val day = java.time.Instant.ofEpochMilli(start).atZone(zone).toLocalDate()
        val amount = adjustedSegment(start, end, Store.isSleepScheduleEnabled(c), Store.sleepStart(c), Store.sleepEnd(c))
        Store.setLongest(c, day, amount)
    }

    fun splitAndAddSegment(c: Context, start: Long, end: Long) {
        if (end <= start) return
        val zone = java.time.ZoneId.systemDefault()
        var day = java.time.Instant.ofEpochMilli(start).atZone(zone).toLocalDate()
        val last = java.time.Instant.ofEpochMilli(end - 1).atZone(zone).toLocalDate()
        while (!day.isAfter(last)) {
            val dayStart = day.atStartOfDay(zone).toInstant().toEpochMilli()
            val dayEnd = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            val partStart = maxOf(start, dayStart)
            val partEnd = minOf(end, dayEnd)
            val amount = adjustedSegment(partStart, partEnd, Store.isSleepScheduleEnabled(c), Store.sleepStart(c), Store.sleepEnd(c))
            Store.addDaily(c, day, amount)
            day = day.plusDays(1)
        }
    }

    fun adjustedToday(c: Context, now: Long = System.currentTimeMillis()): Long {
        val today = LocalDate.now()
        var total = Store.daily(c, today)
        val start = Store.offStart(c)
        if (start > 0L) {
            val zone = java.time.ZoneId.systemDefault()
            val todayStart = today.atStartOfDay(zone).toInstant().toEpochMilli()
            total += adjustedSegment(maxOf(start, todayStart), now, Store.isSleepScheduleEnabled(c), Store.sleepStart(c), Store.sleepEnd(c))
        }
        return total
    }

    fun longestToday(c: Context, now: Long = System.currentTimeMillis()): Long {
        val today = LocalDate.now()
        var longest = Store.longest(c, today)
        val start = Store.offStart(c)
        if (start > 0L) {
            val current = adjustedSegment(start, now, Store.isSleepScheduleEnabled(c), Store.sleepStart(c), Store.sleepEnd(c))
            if (current > longest) longest = current
        }
        return longest
    }

    fun format(ms: Long): String {
        val totalMin = ms / MINUTE
        return "${totalMin / 60}h ${totalMin % 60}m"
    }

    fun formatMinutes(min: Int): String = "%02d:%02d".format(min / 60, min % 60)
}
